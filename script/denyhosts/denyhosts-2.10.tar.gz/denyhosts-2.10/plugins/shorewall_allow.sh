#!/bin/sh
#
# St�phane LeDauphin <stephane@gaelane.org>
#
/sbin/shorewall allow $1

